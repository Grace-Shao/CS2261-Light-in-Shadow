#ifndef PLAYER_H
#define PLAYER_H

void initPlayer();
void updatePlayer();
void drawPlayer();

#endif // PLAYER_H
