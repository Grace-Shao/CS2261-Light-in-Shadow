
//{{BLOCK(spritesheet1)

//======================================================================
//
//	spritesheet1, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 1024 tiles not compressed
//	Total size: 512 + 32768 = 33280
//
//	Time-stamp: 2024-11-07, 16:47:04
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPRITESHEET1_H
#define GRIT_SPRITESHEET1_H

#define spritesheet1TilesLen 32768
extern const unsigned short spritesheet1Tiles[16384];

#define spritesheet1PalLen 512
extern const unsigned short spritesheet1Pal[256];

#endif // GRIT_SPRITESHEET1_H

//}}BLOCK(spritesheet1)
