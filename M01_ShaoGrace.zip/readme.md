**What is finished about the game so far**
- The flashlight functionality (had to do some big brain thinking here)
- enemies randomly choose a part of the screen to lurk out, will randomly attack player (25% chance of attacking)
**What still needs to be added**
- flashlight needs to follow player
- when flashlight collides with enemy, it "freezes the enemy"
- art needs to be updated (using bugs bunny as a placeholder as I don't have other art)
**Any bugs you have found**
- bg needs to be centered
- probably more
**For our sake, how to play/navigate the game in its current state (and see anything you want us to see)**
- the title screen is blank, and click start to transition between start, instructions, pause/unpause, lose/win, back to start
- Button B is walk left, button A is walk right
- WASD is which direction to point the light at.
