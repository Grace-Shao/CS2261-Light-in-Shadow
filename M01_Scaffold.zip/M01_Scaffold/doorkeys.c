#include "gba.h"
#include "mode0.h"
#include "sprites.h"
#include "print.h"
#include "game.h"
#include "player.h"
#include "enemy.h"
#include "flashlight.h"
#include "doorkeys.h"
#include <stdlib.h>
#include <time.h>

SPRITE keys[KEYCOUNT];
SPRITE doors[DOORCOUNT];
SPRITE player;

// keys are oam 20-22
// doors oam 25 - 29
void initBasicKeys() {
    for (int i = 0; i < KEYCOUNT; i++) {
        keys[i].oamIndex = 20 + i;
        keys[i].height = 16;
        keys[i].width = 8;
    }
}

void initBasicDoors() {
    for (int i = 0; i < DOORCOUNT; i++) {
        doors[i].oamIndex = 25 + i;
        doors[i].height = 32;
        doors[i].width = 16;
    }
}
void initKeysLevel1(){
    // Manually set unique x and y positions for each key
    for (int i = 0; i < 2; i++) {
        keys[i].isActive = 1;
    }
    keys[0].x = 100;
    keys[0].y = 50;
    keys[1].x = 60;
    keys[1].y = 100;
}

void initDoorsLevel1(){
    for (int i = 0; i < 2; i++) {
        doors[i].isActive = 1;
    }
    doors[0].x = 150;
    doors[0].y = 75;
    doors[1].x = 200;
    doors[1].y = 120;
}
// TODO: key randomly jumps to new spot
void keyCollision() {
    for (int i = 0; i < KEYCOUNT; i++) {
        if (keys[i].isActive && collision(player.x, player.y, player.width, player.height, keys[i].x, keys[i].y, keys[i].width, keys[i].height)) {
            keys[i].isActive = 0;
            shadowOAM[keys[i].oamIndex].attr0 = ATTR0_HIDE;
            mgba_printf("Collided with key %d\n", i);
        }
    }
}

void enterDoor() {
    for (int i = 0; i < DOORCOUNT; i++) {
        if (doors[i].isActive && collision(player.x, player.y, player.width, player.height, doors[i].x, doors[i].y, doors[i].width, doors[i].height)) {
            // if u have key

            mgba_printf("Entered door %d\n", i);
            // Add any additional logic for entering the door here
        }
    }
}

void drawKeys() {
    for (int i = 0; i < KEYCOUNT; i++) {
        if (keys[i].isActive) {
            shadowOAM[keys[i].oamIndex].attr0 = ATTR0_TALL | ATTR0_Y(keys[i].y - vOff);
            shadowOAM[keys[i].oamIndex].attr1 = ATTR1_X(keys[i].x - hOff) | ATTR1_TINY;
            shadowOAM[keys[i].oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_PRIORITY(1) | ATTR2_TILEID(6, 25);
        }
    }
}

void drawDoors() {
    for (int i = 0; i < DOORCOUNT; i++) {
        if (doors[i].isActive) {
            shadowOAM[doors[i].oamIndex].attr0 = ATTR0_TALL | ATTR0_Y(doors[i].y - vOff);
            shadowOAM[doors[i].oamIndex].attr1 = ATTR1_X(doors[i].x - hOff) | ATTR1_MEDIUM;
            shadowOAM[doors[i].oamIndex].attr2 = ATTR2_PALROW(0) | ATTR2_PRIORITY(1) | ATTR2_TILEID(16, 4);
        }
    }
}