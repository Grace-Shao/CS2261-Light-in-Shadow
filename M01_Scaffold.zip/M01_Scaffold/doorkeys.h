#define KEYCOUNT 3
#define DOORCOUNT 4

void initBasicKeys();
void initDoors();
void initKeysLevel1();
void initDoorsLevel1();
void keyCollision();
void drawKeys();
void drawDoors();

// special key struct that inherits from sprite, w few extra capabilities
typedef struct {
    SPRITE base; // Embed the SPRITE struct
    int isCollected;
} KEY;

typedef struct {
    SPRITE base; // Embed the SPRITE struct
    int health;
    int isUpDoor;
    int hasKey;
    struct DOOR* leadsTo;  
} DOOR;